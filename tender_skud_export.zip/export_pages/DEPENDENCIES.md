# Зависимости для миграции страниц СКУД и Тендерное управление

## NPM пакеты
```json
{
  "dependencies": {
    "@supabase/supabase-js": "^2.x",
    "xlsx": "^0.18.x",
    "lucide-react": "^0.x",
    "react": "^18.x",
    "react-router-dom": "^6.x"
  }
}
```

## Supabase настройка
В `lib/supabase.ts` используются переменные окружения:
- `VITE_SUPABASE_URL` — URL вашего Supabase проекта
- `VITE_SUPABASE_PUBLISHABLE_DEFAULT_KEY` — публичный ключ Supabase

## Таблицы БД

### 1. tender_employees (основная таблица сотрудников)
```sql
CREATE TABLE tender_employees (
  id SERIAL PRIMARY KEY,
  full_name VARCHAR(255) NOT NULL,
  position VARCHAR(255) NOT NULL,
  hire_date DATE NOT NULL,
  birth_date DATE,
  group_name VARCHAR(100),
  current_salary DECIMAL(12,2) DEFAULT 0,
  is_archived BOOLEAN DEFAULT false,
  archived_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### 2. tender_salary_history (история окладов)
```sql
CREATE TABLE tender_salary_history (
  id SERIAL PRIMARY KEY,
  employee_id INTEGER NOT NULL REFERENCES tender_employees(id) ON DELETE CASCADE,
  salary DECIMAL(12,2) NOT NULL,
  effective_date DATE NOT NULL,
  note TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### 3. tender_timesheet (табель учёта)
См. файл: `supabase/001_tender_timesheet.sql`

### 4. skud_events и skud_daily_summary
См. файл: `supabase/004_skud_system.sql`

## Внешние зависимости (опционально)

### calendar_days (календарь рабочих дней)
Используется для определения рабочих/выходных дней. Если вам не нужен календарь из другого проекта, можно:
1. Создать свою таблицу calendar_days
2. Или захардкодить выходные (сб, вс)

```sql
CREATE TABLE calendar_days (
  id SERIAL PRIMARY KEY,
  date DATE NOT NULL UNIQUE,
  status TEXT NOT NULL CHECK (status IN ('work', 'worked', 'vacation', 'dayoff')),
  user_id UUID REFERENCES auth.users(id)
);
```

### salary_settings (настройки зарплаты)
Используется для `work_days_norm` — нормы рабочих дней в месяце.
Если не нужна интеграция с зарплатой, можно использовать константу 22.

```sql
CREATE TABLE salary_settings (
  id SERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  year INTEGER NOT NULL,
  month INTEGER NOT NULL,
  base_salary DECIMAL(12,2),
  bonus DECIMAL(12,2) DEFAULT 0,
  work_days_norm INTEGER DEFAULT 22,
  UNIQUE(user_id, year, month)
);
```

## CSS переменные
В стилях используются CSS-переменные для тем. Минимальный набор:

```css
:root {
  --primary: #3b82f6;
  --primary-hover: #2563eb;
  --danger: #ef4444;
  --success: #4caf50;
  --warning: #ff9800;

  --bg: #ffffff;
  --surface-1: #f8fafc;
  --surface-2: #f1f5f9;
  --surface-3: #e2e8f0;

  --text-1: #0f172a;
  --text-2: #475569;
  --text-3: #94a3b8;

  --border: #e2e8f0;
  --border-light: #f1f5f9;

  --radius-sm: 4px;
  --radius-md: 8px;
  --transition: 0.2s;
}

[data-theme="dark"] {
  --bg: #0f172a;
  --surface-1: #1e293b;
  --surface-2: #334155;
  --surface-3: #475569;

  --text-1: #f8fafc;
  --text-2: #cbd5e1;
  --text-3: #64748b;

  --border: #334155;
  --border-light: #1e293b;
}
```

## Роутинг
Добавьте маршруты в ваш роутер:

```tsx
import TenderPage from './pages/tender/TenderPage'
import SKUDPage from './pages/skud/SKUDPage'

// В вашем роутере:
<Route path="/tender" element={<TenderPage />} />
<Route path="/skud" element={<SKUDPage />} />
```

## Иконки Lucide
Используются иконки из `lucide-react`:
- Shield, ChevronLeft, ChevronRight, Upload, Table, LayoutList, Trash2 (СКУД)
- Users, Plus, Upload, Search, Calendar, Archive, и др. (Тендер)
