export interface Employee {
  id: number
  full_name: string
  position: string
  hire_date: string
  birth_date: string | null
  group_name: string | null
  current_salary: number
  is_archived: boolean
  archived_at: string | null
  created_at: string
}

export interface ImportPreview {
  full_name: string
  position: string
  hire_date: string
  birth_date: string | null
  salary: number
  group_name: string | null
}

export interface SalaryHistory {
  id: number
  employee_id: number
  salary: number
  effective_date: string
  note: string | null
}

export interface EditedEmployee {
  full_name?: string
  position?: string
}

export interface CalendarDay {
  day: number
  isCurrentMonth: boolean
  birthdays: Employee[]
}

export type TimeStatus = 'work' | 'vacation' | 'dayoff' | 'remote' | 'unpaid' | 'absent'

export interface TimeEntry {
  id: number
  employee_id: number
  work_date: string
  status: TimeStatus
  hours_worked: number | null
  is_correction: boolean
  created_at: string
  updated_at: string
}

export interface TimesheetImportRow {
  full_name: string
  entries: { date: string; status: TimeStatus; hours_worked: number | null; is_correction: boolean }[]
}

export interface TimesheetParseResult {
  found: TimesheetImportRow[]
  notFound: string[]
}
