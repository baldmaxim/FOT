import { useState, useCallback } from 'react'
import { supabase } from '../../../lib/supabase'
import * as XLSX from 'xlsx'
import { Employee, ImportPreview, SalaryHistory, TimeEntry, TimesheetImportRow, TimeStatus, TimesheetParseResult } from '../types'

export function useTenderData() {
  const [employees, setEmployees] = useState<Employee[]>([])
  const [salaryHistory, setSalaryHistory] = useState<{ [key: number]: SalaryHistory[] }>({})
  const [loading, setLoading] = useState(true)

  const loadEmployees = useCallback(async (showArchived: boolean) => {
    setLoading(true)
    const { data } = await supabase
      .from('tender_employees')
      .select('*')
      .eq('is_archived', showArchived)
      .order('full_name')

    if (data) {
      setEmployees(data)
      const ids = data.map(e => e.id)
      if (ids.length > 0) {
        const { data: history } = await supabase
          .from('tender_salary_history')
          .select('*')
          .in('employee_id', ids)
          .order('effective_date', { ascending: false })

        if (history) {
          const grouped: { [key: number]: SalaryHistory[] } = {}
          history.forEach(h => {
            if (!grouped[h.employee_id]) grouped[h.employee_id] = []
            grouped[h.employee_id].push(h)
          })
          setSalaryHistory(grouped)
        }
      }
    }
    setLoading(false)
  }, [])

  const addEmployee = async (
    formName: string,
    formPosition: string,
    formHireDate: string,
    formSalary: string
  ) => {
    const salary = parseFloat(formSalary.replace(/\s/g, '')) || 0
    const today = new Date().toISOString().split('T')[0]
    const { data, error } = await supabase
      .from('tender_employees')
      .insert({
        full_name: formName,
        position: formPosition,
        hire_date: formHireDate,
        current_salary: salary
      })
      .select()
      .single()

    if (!error && data) {
      await supabase.from('tender_salary_history').insert({
        employee_id: data.id,
        salary: salary,
        effective_date: today,
        note: 'Текущий оклад'
      })
      return true
    }
    return false
  }

  const archiveEmployee = async (employeeId: number) => {
    await supabase
      .from('tender_employees')
      .update({
        is_archived: true,
        archived_at: new Date().toISOString()
      })
      .eq('id', employeeId)
  }

  const restoreEmployee = async (employeeId: number) => {
    await supabase
      .from('tender_employees')
      .update({
        is_archived: false,
        archived_at: null
      })
      .eq('id', employeeId)
  }

  const massArchive = async (ids: number[]) => {
    await supabase
      .from('tender_employees')
      .update({ is_archived: true, archived_at: new Date().toISOString() })
      .in('id', ids)
  }

  const saveEditedEmployees = async (editedEmployees: { [id: number]: { full_name?: string; position?: string } }) => {
    const updates = Object.entries(editedEmployees)
      .filter(([_, changes]) => Object.keys(changes).length > 0)
      .map(([idStr, changes]) => ({
        id: parseInt(idStr),
        ...changes,
        updated_at: new Date().toISOString()
      }))

    if (updates.length === 0) return

    // Batch update через upsert
    await supabase
      .from('tender_employees')
      .upsert(updates, { ignoreDuplicates: false })
  }

  const addRaise = async (
    employee: Employee,
    raiseAmount: string,
    raiseDate: string,
    raiseNote: string
  ) => {
    const raiseSum = parseFloat(raiseAmount.replace(/\s/g, '')) || 0
    const today = new Date().toISOString().split('T')[0]
    const isHistory = raiseDate < today

    let newSalary: number
    const history = salaryHistory[employee.id] || []

    if (isHistory) {
      const entriesAfter = history.filter(h => h.effective_date > raiseDate)
      if (entriesAfter.length > 0) {
        const nextEntry = entriesAfter[entriesAfter.length - 1]
        newSalary = nextEntry.salary - raiseSum
      } else {
        newSalary = employee.current_salary - raiseSum
      }

      // Batch update для старых записей
      const olderEntries = history.filter(h => h.effective_date < raiseDate)
      if (olderEntries.length > 0) {
        const updates = olderEntries.map(entry => ({
          id: entry.id,
          salary: entry.salary - raiseSum,
          employee_id: entry.employee_id,
          effective_date: entry.effective_date,
          note: entry.note
        }))
        await supabase.from('tender_salary_history').upsert(updates, { ignoreDuplicates: false })
      }
    } else {
      newSalary = employee.current_salary + raiseSum
    }

    await supabase.from('tender_salary_history').insert({
      employee_id: employee.id,
      salary: newSalary,
      effective_date: raiseDate,
      note: raiseNote || null
    })

    if (!isHistory) {
      await supabase
        .from('tender_employees')
        .update({
          current_salary: newSalary,
          updated_at: new Date().toISOString()
        })
        .eq('id', employee.id)
    }
  }

  const deleteRaise = async (historyId: number, employeeId: number) => {
    await supabase.from('tender_salary_history').delete().eq('id', historyId)

    const { data: remaining } = await supabase
      .from('tender_salary_history')
      .select('salary')
      .eq('employee_id', employeeId)
      .order('effective_date', { ascending: false })
      .limit(1)
      .single()

    if (remaining) {
      await supabase
        .from('tender_employees')
        .update({ current_salary: remaining.salary })
        .eq('id', employeeId)
    }
  }

  const parseExcelDate = (raw: unknown): string | null => {
    if (!raw) return null
    if (typeof raw === 'number') {
      const date = XLSX.SSF.parse_date_code(raw)
      return `${date.y}-${String(date.m).padStart(2, '0')}-${String(date.d).padStart(2, '0')}`
    }
    return String(raw)
  }

  const parseImportFile = (file: File): Promise<ImportPreview[]> => {
    return new Promise((resolve) => {
      const reader = new FileReader()
      reader.onload = (evt) => {
        const data = evt.target?.result
        const workbook = XLSX.read(data, { type: 'binary' })
        const sheet = workbook.Sheets[workbook.SheetNames[0]]
        const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1 })

        const dataRows = rows.filter((row: any[], i: number) => i > 0 && row.length >= 4)
        const preview: ImportPreview[] = []

        for (const row of dataRows) {
          const [name, position, hireDateRaw, salaryRaw, birthDateRaw, groupRaw] = row as unknown[]
          if (!name) continue

          const hireDate = parseExcelDate(hireDateRaw)
          const birthDate = parseExcelDate(birthDateRaw)
          const salary = typeof salaryRaw === 'number' ? salaryRaw : parseFloat(String(salaryRaw).replace(/\s/g, '')) || 0
          const groupName = groupRaw ? String(groupRaw).trim() : null

          preview.push({
            full_name: String(name).trim(),
            position: String(position).trim(),
            hire_date: hireDate || '',
            birth_date: birthDate,
            salary,
            group_name: groupName
          })
        }

        resolve(preview)
      }
      reader.readAsBinaryString(file)
    })
  }

  const confirmImport = async (importPreview: ImportPreview[], replaceOnImport: boolean) => {
    const today = new Date().toISOString().split('T')[0]

    if (replaceOnImport) {
      await supabase.from('tender_salary_history').delete().neq('id', 0)
      await supabase.from('tender_employees').delete().neq('id', 0)
    }

    // Batch insert сотрудников
    const { data: insertedEmployees } = await supabase
      .from('tender_employees')
      .insert(
        importPreview.map(item => ({
          full_name: item.full_name,
          position: item.position,
          hire_date: item.hire_date,
          birth_date: item.birth_date,
          group_name: item.group_name,
          current_salary: item.salary
        }))
      )
      .select('id, full_name')

    if (insertedEmployees && insertedEmployees.length > 0) {
      // Создаем map для связи имени с id
      const employeeMap = new Map(insertedEmployees.map(e => [e.full_name, e.id]))

      // Batch insert истории окладов
      const historyEntries = importPreview
        .map(item => {
          const employeeId = employeeMap.get(item.full_name)
          if (!employeeId) return null
          return {
            employee_id: employeeId,
            salary: item.salary,
            effective_date: today,
            note: 'Текущий оклад (импорт)'
          }
        })
        .filter(Boolean)

      if (historyEntries.length > 0) {
        await supabase.from('tender_salary_history').insert(historyEntries)
      }
    }
  }

  const parseTimesheetFile = async (file: File, year: number, month: number): Promise<TimesheetParseResult> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = async (evt) => {
        try {
          const data = evt.target?.result
          const workbook = XLSX.read(data, { type: 'binary' })
          const sheet = workbook.Sheets[workbook.SheetNames[0]]
          const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1 })

          console.log('Парсинг табеля: всего строк в Excel:', rows.length)

          // Получаем всех сотрудников из БД
          const { data: allEmployees } = await supabase
            .from('tender_employees')
            .select('full_name')
            .eq('is_archived', false)

          const employeeNames = new Set(allEmployees?.map(e => e.full_name.toLowerCase().trim()) || [])
          console.log('Сотрудников в БД:', employeeNames.size)

          const daysInMonth = new Date(year, month, 0).getDate()
          const found: TimesheetImportRow[] = []
          const notFound: string[] = []

          // Начинаем с 4-й строки (индекс 3), пропускаем заголовки
          for (let i = 3; i < rows.length; i++) {
            const row = rows[i] as any[]
            if (!row[0]) continue

            const fullName = String(row[0]).trim()
            const nameLower = fullName.toLowerCase().trim()

            // Проверяем есть ли сотрудник в БД
            if (!employeeNames.has(nameLower)) {
              notFound.push(fullName)
              continue
            }

            const entries: { date: string; status: TimeStatus; hours_worked: number | null; is_correction: boolean }[] = []

            for (let day = 1; day <= daysInMonth; day++) {
              const cellValue = row[day] ? String(row[day]).trim() : ''
              if (!cellValue) continue

              const date = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`
              let status: TimeStatus = 'work'
              let hours: number | null = null
              let isCorrection = false

              const upper = cellValue.toUpperCase()

              if (upper === 'В') {
                status = 'dayoff'
              } else if (upper === 'ОТ') {
                status = 'vacation'
              } else if (upper === 'Н') {
                status = 'absent'
              } else if (upper === 'У') {
                status = 'remote'
              } else if (upper === 'ОШ') {
                status = 'unpaid'
              } else if (upper.startsWith('Я')) {
                status = 'work'
                const match = cellValue.match(/(\d+):(\d+)/)
                if (match) {
                  hours = parseFloat(match[1]) + parseFloat(match[2]) / 60
                }
                isCorrection = upper.includes('К')
              }

              entries.push({ date, status, hours_worked: hours, is_correction: isCorrection })
            }

            if (entries.length > 0) {
              found.push({ full_name: fullName, entries })
            }
          }

          console.log('Парсинг завершён, найдено:', found.length, 'не найдено:', notFound.length)
          resolve({ found, notFound })
        } catch (error) {
          console.error('Ошибка парсинга файла:', error)
          reject(error)
        }
      }
      reader.onerror = () => {
        reject(new Error('Ошибка чтения файла'))
      }
      reader.readAsBinaryString(file)
    })
  }

  const confirmTimesheetImport = async (timesheetData: TimesheetImportRow[]) => {
    // Получаем всех сотрудников за один запрос
    const names = timesheetData.map(row => row.full_name)
    const { data: employees } = await supabase
      .from('tender_employees')
      .select('id, full_name')
      .in('full_name', names)

    if (!employees || employees.length === 0) {
      throw new Error('Ни один сотрудник не найден в БД')
    }

    // Создаем map для быстрого поиска
    const employeeMap = new Map(employees.map(e => [e.full_name, e.id]))

    // Собираем все записи для batch upsert
    const allEntries: any[] = []
    for (const row of timesheetData) {
      const employeeId = employeeMap.get(row.full_name)
      if (!employeeId) {
        console.warn(`Сотрудник "${row.full_name}" не найден`)
        continue
      }

      for (const entry of row.entries) {
        allEntries.push({
          employee_id: employeeId,
          work_date: entry.date,
          status: entry.status,
          hours_worked: entry.hours_worked,
          is_correction: entry.is_correction
        })
      }
    }

    // Batch upsert всех записей за один запрос
    if (allEntries.length > 0) {
      const { error } = await supabase
        .from('tender_timesheet')
        .upsert(allEntries, { ignoreDuplicates: false })

      if (error) {
        console.error('Ошибка batch upsert табеля:', error)
        throw error
      }
    }
  }

  const loadTimesheet = async (year: number, month: number): Promise<{ [employeeId: number]: TimeEntry[] }> => {
    const startDate = `${year}-${String(month).padStart(2, '0')}-01`
    const endDate = `${year}-${String(month).padStart(2, '0')}-${new Date(year, month, 0).getDate()}`

    const { data } = await supabase
      .from('tender_timesheet')
      .select('*')
      .gte('work_date', startDate)
      .lte('work_date', endDate)
      .order('work_date')

    if (!data) return {}

    const grouped: { [employeeId: number]: TimeEntry[] } = {}
    data.forEach((entry: TimeEntry) => {
      if (!grouped[entry.employee_id]) grouped[entry.employee_id] = []
      grouped[entry.employee_id].push(entry)
    })

    return grouped
  }

  const clearTimesheet = async (year: number, month: number) => {
    const startDate = `${year}-${String(month).padStart(2, '0')}-01`
    const endDate = `${year}-${String(month).padStart(2, '0')}-${new Date(year, month, 0).getDate()}`

    console.log('Очистка табеля:', startDate, '-', endDate)

    const { error } = await supabase
      .from('tender_timesheet')
      .delete()
      .gte('work_date', startDate)
      .lte('work_date', endDate)

    if (error) {
      console.error('Ошибка очистки табеля:', error)
      throw error
    }

    console.log('Табель очищен')
  }

  const addMissingEmployees = async (names: string[]) => {
    console.log('Добавление сотрудников:', names)
    const today = new Date().toISOString().split('T')[0]

    // Batch insert сотрудников
    const { data: insertedEmployees, error } = await supabase
      .from('tender_employees')
      .insert(
        names.map(name => ({
          full_name: name,
          position: 'Не указана',
          hire_date: today,
          current_salary: 0
        }))
      )
      .select('id')

    if (error) {
      console.error('Ошибка batch добавления сотрудников:', error)
      throw error
    }

    if (insertedEmployees && insertedEmployees.length > 0) {
      // Batch insert истории для всех новых сотрудников
      await supabase.from('tender_salary_history').insert(
        insertedEmployees.map(emp => ({
          employee_id: emp.id,
          salary: 0,
          effective_date: today,
          note: 'Создан при импорте табеля'
        }))
      )
    }

    console.log('Сотрудники добавлены')
  }

  const updateEmployeeHireDate = async (employeeId: number, newHireDate: string) => {
    await supabase
      .from('tender_employees')
      .update({ hire_date: newHireDate })
      .eq('id', employeeId)
  }

  const deleteEmployee = async (employeeId: number) => {
    await supabase
      .from('tender_employees')
      .delete()
      .eq('id', employeeId)
  }

  return {
    employees,
    salaryHistory,
    loading,
    loadEmployees,
    addEmployee,
    updateEmployeeHireDate,
    deleteEmployee,
    archiveEmployee,
    restoreEmployee,
    massArchive,
    saveEditedEmployees,
    addRaise,
    deleteRaise,
    parseImportFile,
    confirmImport,
    parseTimesheetFile,
    confirmTimesheetImport,
    loadTimesheet,
    clearTimesheet,
    addMissingEmployees
  }
}
