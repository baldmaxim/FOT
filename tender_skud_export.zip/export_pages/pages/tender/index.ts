export { default } from './TenderPage'
