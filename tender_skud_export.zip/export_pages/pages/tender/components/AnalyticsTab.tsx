import { useMemo, useState, useEffect } from 'react'
import { Users, Wallet, TrendingUp, Calendar, Award, UserPlus, Clock } from 'lucide-react'
import { XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, BarChart, Bar, Legend } from 'recharts'
import { Employee, SalaryHistory } from '../types'
import { calculateActualSalaryFromTimesheet } from '../utils'

interface AnalyticsTabProps {
  employees: Employee[]
  archivedEmployees: Employee[]
  salaryHistory: { [key: number]: SalaryHistory[] }
  onLoadTimesheet: (year: number, month: number) => Promise<{ [employeeId: number]: import('../types').TimeEntry[] }>
}

const COLORS = ['#C4A77D', '#D4C5AE', '#B5A594', '#A39988', '#C9BAAA', '#D9D0C4', '#BCB3A8']

const formatMoney = (value: number) => {
  return new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 0 }).format(value)
}

export default function AnalyticsTab({ employees, archivedEmployees, salaryHistory, onLoadTimesheet }: AnalyticsTabProps) {
  const [timesheetData, setTimesheetData] = useState<{ [key: string]: { [employeeId: number]: import('../types').TimeEntry[] } }>({})

  useEffect(() => {
    const loadAllTimesheets = async () => {
      const now = new Date()
      const currentYear = now.getFullYear()
      const currentMonth = now.getMonth()
      const data: { [key: string]: { [employeeId: number]: import('../types').TimeEntry[] } } = {}

      for (let i = 11; i >= 0; i--) {
        const date = new Date(currentYear, currentMonth - i, 1)
        const year = date.getFullYear()
        const month = date.getMonth() + 1
        const key = `${year}-${month}`

        try {
          const timesheet = await onLoadTimesheet(year, month)
          data[key] = timesheet
        } catch (error) {
          console.error(`Ошибка загрузки табеля за ${year}-${month}:`, error)
          data[key] = {}
        }
      }

      setTimesheetData(data)
    }

    loadAllTimesheets()
  }, [onLoadTimesheet])

  const analytics = useMemo(() => {
    const now = new Date()
    const currentYear = now.getFullYear()
    const currentMonth = now.getMonth()

    // Базовые метрики
    const totalEmployees = employees.length
    const totalSalary = employees.reduce((sum, e) => sum + e.current_salary, 0)
    const avgSalary = totalEmployees > 0 ? totalSalary / totalEmployees : 0

    // Средний стаж
    const avgTenure = totalEmployees > 0
      ? employees.reduce((sum, e) => {
          const hire = new Date(e.hire_date)
          const years = (now.getTime() - hire.getTime()) / (365.25 * 24 * 60 * 60 * 1000)
          return sum + years
        }, 0) / totalEmployees
      : 0

    // Распределение по группам
    const groupStats: { [key: string]: { count: number; salary: number } } = {}
    employees.forEach(e => {
      const group = e.group_name || 'Без группы'
      if (!groupStats[group]) groupStats[group] = { count: 0, salary: 0 }
      groupStats[group].count++
      groupStats[group].salary += e.current_salary
    })
    const groupData = Object.entries(groupStats).map(([name, data]) => ({
      name: `${name} (${data.count} чел.)`,
      value: data.count,
      salary: data.salary
    })).sort((a, b) => b.salary - a.salary)

    // Распределение по стажу
    const tenureBuckets = [
      { label: '< 1 года', min: 0, max: 1, count: 0 },
      { label: '1-2 года', min: 1, max: 2, count: 0 },
      { label: '2-3 года', min: 2, max: 3, count: 0 },
      { label: '3-5 лет', min: 3, max: 5, count: 0 },
      { label: '5+ лет', min: 5, max: 100, count: 0 }
    ]
    employees.forEach(e => {
      const hire = new Date(e.hire_date)
      const years = (now.getTime() - hire.getTime()) / (365.25 * 24 * 60 * 60 * 1000)
      const bucket = tenureBuckets.find(b => years >= b.min && years < b.max)
      if (bucket) bucket.count++
    })

    // Динамика ФОТ по месяцам (последние 12 месяцев)
    const fotHistory: { month: string; plan: number; fact: number }[] = []
    for (let i = 11; i >= 0; i--) {
      const date = new Date(currentYear, currentMonth - i, 1)
      const year = date.getFullYear()
      const month = date.getMonth() + 1
      const monthKey = date.toLocaleDateString('ru-RU', { month: 'short', year: '2-digit' })
      const timesheetKey = `${year}-${month}`

      // Считаем плановый ФОТ на конец месяца
      let plannedFot = 0
      employees.forEach(e => {
        const hireDate = new Date(e.hire_date)
        if (hireDate <= date) {
          const history = salaryHistory[e.id] || []
          const relevantHistory = history
            .filter(h => new Date(h.effective_date) <= date)
            .sort((a, b) => new Date(b.effective_date).getTime() - new Date(a.effective_date).getTime())

          if (relevantHistory.length > 0) {
            plannedFot += relevantHistory[0].salary
          } else {
            plannedFot += e.current_salary
          }
        }
      })

      // Считаем фактический ФОТ на основе табеля
      let actualFot = 0
      const timesheet = timesheetData[timesheetKey] || {}
      const daysInMonth = new Date(year, month, 0).getDate()

      // Вычисляем норму рабочих дней для месяца
      let workNormDays = 0
      for (let day = 1; day <= daysInMonth; day++) {
        const d = new Date(year, month - 1, day)
        const dayOfWeek = d.getDay()
        const isHoliday = year === 2026 && month === 1 && day <= 11
        if (!isHoliday && dayOfWeek !== 0 && dayOfWeek !== 6) {
          workNormDays++
        }
      }

      employees.forEach(e => {
        const hireDate = new Date(e.hire_date)
        if (hireDate <= date && workNormDays > 0) {
          const history = salaryHistory[e.id] || []
          const relevantHistory = history
            .filter(h => new Date(h.effective_date) <= date)
            .sort((a, b) => new Date(b.effective_date).getTime() - new Date(a.effective_date).getTime())

          // Создаём employee объект с зарплатой на эту дату
          const employeeAtDate = {
            ...e,
            current_salary: relevantHistory.length > 0 ? relevantHistory[0].salary : e.current_salary
          }

          const entries = timesheet[e.id] || []
          const { actualSalary } = calculateActualSalaryFromTimesheet(
            employeeAtDate,
            entries,
            year,
            month,
            workNormDays
          )
          actualFot += actualSalary
        }
      })

      fotHistory.push({ month: monthKey, plan: plannedFot, fact: actualFot })
    }

    // Топ зарплат
    const topSalaries = [...employees]
      .sort((a, b) => b.current_salary - a.current_salary)
      .slice(0, 5)

    // Новые сотрудники (за последние 90 дней)
    const threeMonthsAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000)
    const newHires = employees
      .filter(e => new Date(e.hire_date) >= threeMonthsAgo)
      .sort((a, b) => new Date(b.hire_date).getTime() - new Date(a.hire_date).getTime())

    // Ближайшие дни рождения (30 дней)
    const upcomingBirthdays = employees
      .filter(e => e.birth_date)
      .map(e => {
        const bd = new Date(e.birth_date!)
        const thisYearBd = new Date(currentYear, bd.getMonth(), bd.getDate())
        if (thisYearBd < now) thisYearBd.setFullYear(currentYear + 1)
        const daysUntil = Math.ceil((thisYearBd.getTime() - now.getTime()) / (24 * 60 * 60 * 1000))
        return { ...e, daysUntil, nextBirthday: thisYearBd }
      })
      .filter(e => e.daysUntil <= 30 && e.daysUntil >= 0)
      .sort((a, b) => a.daysUntil - b.daysUntil)

    // Текучесть за год
    const yearAgo = new Date(currentYear - 1, currentMonth, 1)
    const hiredThisYear = employees.filter(e => new Date(e.hire_date) >= yearAgo).length
    const archivedThisYear = archivedEmployees.filter(e =>
      e.archived_at && new Date(e.archived_at) >= yearAgo
    ).length

    // Рост ФОТ
    const fotGrowth = fotHistory.length >= 2
      ? ((fotHistory[fotHistory.length - 1].plan - fotHistory[0].plan) / fotHistory[0].plan * 100)
      : 0

    return {
      totalEmployees,
      totalSalary,
      avgSalary,
      avgTenure,
      groupData,
      tenureBuckets,
      fotHistory,
      topSalaries,
      newHires,
      upcomingBirthdays,
      hiredThisYear,
      archivedThisYear,
      fotGrowth
    }
  }, [employees, archivedEmployees, salaryHistory, timesheetData])

  return (
    <div className="analytics-tab">
      {/* KPI карточки */}
      <div className="analytics-kpi">
        <div className="kpi-card">
          <div className="kpi-icon"><Users size={24} /></div>
          <div className="kpi-content">
            <span className="kpi-value">{analytics.totalEmployees}</span>
            <span className="kpi-label">Сотрудников</span>
          </div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon"><Wallet size={24} /></div>
          <div className="kpi-content">
            <span className="kpi-value">{formatMoney(analytics.totalSalary)}</span>
            <span className="kpi-label">ФОТ / мес</span>
          </div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon"><TrendingUp size={24} /></div>
          <div className="kpi-content">
            <span className="kpi-value">{formatMoney(analytics.avgSalary)}</span>
            <span className="kpi-label">Средняя ЗП</span>
          </div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon"><Clock size={24} /></div>
          <div className="kpi-content">
            <span className="kpi-value">{analytics.avgTenure.toFixed(1)} лет</span>
            <span className="kpi-label">Средний стаж</span>
          </div>
        </div>
      </div>

      {/* Текучесть */}
      <div className="analytics-turnover">
        <div className="turnover-item positive">
          <UserPlus size={18} />
          <span>+{analytics.hiredThisYear} принято за год</span>
        </div>
        <div className="turnover-item negative">
          <Users size={18} />
          <span>-{analytics.archivedThisYear} уволено за год</span>
        </div>
        <div className={`turnover-item ${analytics.fotGrowth >= 0 ? 'positive' : 'negative'}`}>
          <TrendingUp size={18} />
          <span>{analytics.fotGrowth >= 0 ? '+' : ''}{analytics.fotGrowth.toFixed(1)}% ФОТ за год</span>
        </div>
      </div>

      <div className="analytics-grid">
        {/* Динамика ФОТ */}
        <div className="analytics-card wide">
          <h3>Динамика ФОТ</h3>
          <div className="chart-container">
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={analytics.fotHistory}>
                <XAxis dataKey="month" tick={{ fill: 'var(--text-secondary)', fontSize: 11 }} />
                <YAxis tick={{ fill: 'var(--text-secondary)', fontSize: 11 }} tickFormatter={v => `${(v/1000000).toFixed(1)}М`} />
                <Tooltip
                  formatter={(value, name) => [formatMoney(Number(value)) + ' ₽', name === 'plan' ? 'План' : 'Факт']}
                  contentStyle={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8 }}
                />
                <Legend
                  formatter={(value) => value === 'plan' ? 'План' : 'Факт'}
                  wrapperStyle={{ fontSize: 12, paddingTop: 8 }}
                />
                <Bar dataKey="plan" fill="#C4A77D" radius={[4, 4, 0, 0]} />
                <Bar dataKey="fact" fill="#B5A594" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Распределение по группам */}
        <div className="analytics-card">
          <h3>По группам</h3>
          <div className="chart-container">
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={analytics.groupData}>
                <XAxis dataKey="name" tick={{ fill: 'var(--text-secondary)', fontSize: 11 }} />
                <YAxis tick={{ fill: 'var(--text-secondary)', fontSize: 11 }} tickFormatter={v => `${(v/1000000).toFixed(1)}М`} />
                <Tooltip
                  formatter={(value) => [formatMoney(Number(value)) + ' ₽', 'ФОТ группы']}
                  contentStyle={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8 }}
                />
                <Bar dataKey="salary" radius={[4, 4, 0, 0]}>
                  {analytics.groupData.map((_, index) => (
                    <Cell key={index} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Распределение по стажу */}
        <div className="analytics-card">
          <h3>По стажу</h3>
          <div className="chart-container">
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={analytics.tenureBuckets} layout="vertical">
                <XAxis type="number" tick={{ fill: 'var(--text-secondary)', fontSize: 11 }} />
                <YAxis dataKey="label" type="category" tick={{ fill: 'var(--text-secondary)', fontSize: 11 }} width={70} />
                <Tooltip
                  formatter={(value) => [`${value} чел.`, 'Сотрудников']}
                  contentStyle={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8 }}
                />
                <Bar dataKey="count" fill="#6B99CC" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Топ зарплат */}
        <div className="analytics-card">
          <h3><Award size={16} /> Топ-5 по зарплате</h3>
          <div className="top-list">
            {analytics.topSalaries.map((emp, i) => (
              <div key={emp.id} className="top-item">
                <span className="top-rank">{i + 1}</span>
                <div className="top-info">
                  <span className="top-name">{emp.full_name}</span>
                  <span className="top-position">{emp.position}</span>
                </div>
                <span className="top-salary">{formatMoney(emp.current_salary)} ₽</span>
              </div>
            ))}
          </div>
        </div>

        {/* Ближайшие ДР */}
        <div className="analytics-card">
          <h3><Calendar size={16} /> Дни рождения (30 дней)</h3>
          <div className="events-list">
            {analytics.upcomingBirthdays.length === 0 ? (
              <div className="no-events">Нет ближайших дней рождения</div>
            ) : (
              analytics.upcomingBirthdays.map(emp => (
                <div key={emp.id} className="event-item">
                  <div className="event-date">
                    {emp.daysUntil === 0 ? 'Сегодня!' :
                     emp.daysUntil === 1 ? 'Завтра' :
                     `Через ${emp.daysUntil} дн.`}
                  </div>
                  <div className="event-info">
                    <span className="event-name">{emp.full_name}</span>
                    <span className="event-detail">
                      {emp.nextBirthday.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Новые сотрудники */}
        <div className="analytics-card">
          <h3><UserPlus size={16} /> Новые (90 дней)</h3>
          <div className="events-list">
            {analytics.newHires.length === 0 ? (
              <div className="no-events">Нет новых сотрудников</div>
            ) : (
              analytics.newHires.map(emp => (
                <div key={emp.id} className="event-item">
                  <div className="event-date">
                    {new Date(emp.hire_date).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}
                  </div>
                  <div className="event-info">
                    <span className="event-name">{emp.full_name}</span>
                    <span className="event-detail">{emp.position}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
