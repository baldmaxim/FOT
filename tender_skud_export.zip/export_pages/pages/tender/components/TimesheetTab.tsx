import { useState, useEffect } from 'react'
import { Upload, ChevronLeft, ChevronRight, Trash2 } from 'lucide-react'
import { Employee, TimeEntry, TimesheetImportRow, TimesheetParseResult } from '../types'

interface TimesheetTabProps {
  employees: Employee[]
  onParseTimesheet: (file: File, year: number, month: number) => Promise<TimesheetParseResult>
  onConfirmImport: (data: TimesheetImportRow[]) => Promise<void>
  onLoadTimesheet: (year: number, month: number) => Promise<{ [employeeId: number]: TimeEntry[] }>
  onClearTimesheet: (year: number, month: number) => Promise<void>
  onAddMissingEmployees: (names: string[]) => Promise<void>
  onReloadEmployees: () => Promise<void>
}

export default function TimesheetTab({
  employees,
  onParseTimesheet,
  onConfirmImport,
  onLoadTimesheet,
  onClearTimesheet,
  onAddMissingEmployees,
  onReloadEmployees
}: TimesheetTabProps) {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [timesheet, setTimesheet] = useState<{ [employeeId: number]: TimeEntry[] }>({})
  const [importPreview, setImportPreview] = useState<TimesheetImportRow[]>([])
  const [showPreview, setShowPreview] = useState(false)
  const [importing, setImporting] = useState(false)
  const [selectedEmployee, setSelectedEmployee] = useState<{ emp: Employee; stats: ReturnType<typeof getEmployeeStats> } | null>(null)
  const [notFoundEmployees, setNotFoundEmployees] = useState<string[]>([])
  const [showNotFoundModal, setShowNotFoundModal] = useState(false)
  const [selectedToAdd, setSelectedToAdd] = useState<Set<string>>(new Set())

  const year = currentDate.getFullYear()
  const month = currentDate.getMonth() + 1
  const daysInMonth = new Date(year, month, 0).getDate()

  // Дедупликация сотрудников по ФИО (берем первого с каждым уникальным именем)
  const uniqueEmployees = employees.reduce((acc, emp) => {
    const existing = acc.find(e => e.full_name.toLowerCase().trim() === emp.full_name.toLowerCase().trim())
    if (!existing) {
      acc.push(emp)
    }
    return acc
  }, [] as Employee[])

  useEffect(() => {
    loadData()
  }, [currentDate])

  const loadData = async () => {
    const data = await onLoadTimesheet(year, month)
    setTimesheet(data)
  }

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    try {
      const result = await onParseTimesheet(file, year, month)

      if (result.found.length === 0 && result.notFound.length === 0) {
        alert('Табель пуст или не удалось распознать данные')
        return
      }

      if (result.notFound.length > 0) {
        // Показываем модалку с не найденными сотрудниками
        setNotFoundEmployees(result.notFound)
        setSelectedToAdd(new Set(result.notFound)) // По умолчанию все выбраны
        setImportPreview(result.found)
        setShowNotFoundModal(true)
      } else {
        // Если все найдены - сразу показываем предпросмотр
        setImportPreview(result.found)
        setShowPreview(true)
      }
    } catch (error) {
      console.error('Ошибка парсинга:', error)
      alert('Ошибка при чтении файла: ' + (error as Error).message)
    } finally {
      e.target.value = ''
    }
  }

  const handleConfirmImport = async () => {
    try {
      setImporting(true)
      await onConfirmImport(importPreview)
      setShowPreview(false)
      setImportPreview([])
      await loadData()
    } catch (error) {
      console.error('Ошибка импорта:', error)
      alert('Ошибка при импорте табеля: ' + (error as Error).message)
    } finally {
      setImporting(false)
    }
  }

  const handleConfirmNotFound = async () => {
    try {
      setImporting(true)

      // Добавляем выбранных сотрудников
      if (selectedToAdd.size > 0) {
        await onAddMissingEmployees(Array.from(selectedToAdd))
        await onReloadEmployees()
      }

      setShowNotFoundModal(false)
      setNotFoundEmployees([])
      setSelectedToAdd(new Set())

      // Показываем предпросмотр импорта
      if (importPreview.length > 0) {
        setShowPreview(true)
      } else {
        alert('Нет данных для импорта')
      }
    } catch (error) {
      console.error('Ошибка добавления сотрудников:', error)
      alert('Ошибка при добавлении сотрудников: ' + (error as Error).message)
    } finally {
      setImporting(false)
    }
  }

  const toggleEmployeeSelection = (name: string) => {
    setSelectedToAdd(prev => {
      const newSet = new Set(prev)
      if (newSet.has(name)) {
        newSet.delete(name)
      } else {
        newSet.add(name)
      }
      return newSet
    })
  }

  const toggleSelectAll = () => {
    if (selectedToAdd.size === notFoundEmployees.length) {
      setSelectedToAdd(new Set())
    } else {
      setSelectedToAdd(new Set(notFoundEmployees))
    }
  }

  const handleClear = async () => {
    if (!confirm(`Удалить все записи табеля за ${new Date(year, month - 1).toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' })}?`)) {
      return
    }

    try {
      await onClearTimesheet(year, month)
      await loadData()
    } catch (error) {
      console.error('Ошибка очистки:', error)
      alert('Ошибка при очистке табеля: ' + (error as Error).message)
    }
  }

  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 2, 1))
  }

  const nextMonth = () => {
    setCurrentDate(new Date(year, month, 1))
  }

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      work: 'Я',
      vacation: 'ОТ',
      dayoff: 'В',
      remote: 'У',
      absent: 'Н',
      unpaid: 'ОШ'
    }
    return labels[status] || ''
  }

  const getStatusClass = (status: string) => {
    return `timesheet-cell timesheet-${status}`
  }

  const formatHours = (hours: number | null) => {
    if (!hours) return ''
    const h = Math.floor(hours)
    const m = Math.round((hours - h) * 60)
    return `${h}:${String(m).padStart(2, '0')}`
  }

  const getEmployeeStats = (employeeId: number) => {
    const entries = timesheet[employeeId] || []
    const issues: string[] = []
    let totalWorkedHours = 0
    let totalRequiredHours = 0
    let workedDays = 0

    // Определяем текущую дату
    const today = new Date()
    const todayYear = today.getFullYear()
    const todayMonth = today.getMonth() + 1
    const todayDay = today.getDate()

    // Определяем последний день для проверки
    let lastDayToCheck = daysInMonth
    if (year === todayYear && month === todayMonth) {
      // Если это текущий месяц - проверяем только до сегодняшнего дня
      lastDayToCheck = todayDay
    } else if (year > todayYear || (year === todayYear && month > todayMonth)) {
      // Если это будущий месяц - не проверяем вообще
      return { issues, totalMissingHours: 0, totalWorkedHours, totalRequiredHours, workedDays }
    }

    for (let day = 1; day <= lastDayToCheck; day++) {
      const date = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`
      const dayOfWeek = new Date(date).getDay()
      const entry = entries.find(e => e.work_date === date)

      // Проверяем новогодние праздники (1-11 января 2026)
      const isHoliday = year === 2026 && month === 1 && day <= 11
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6

      // Выходные и праздники
      if (isHoliday || isWeekend) {
        // Если записи нет - пропускаем
        if (!entry) continue

        // Если статус vacation/dayoff/unpaid/absent - пропускаем
        if (entry.status === 'vacation' || entry.status === 'dayoff' || entry.status === 'unpaid' || entry.status === 'absent') {
          continue
        }

        // Выходной: офис = 5ч норма (только если >= 3ч), удаленка = 9ч норма
        if (entry.status === 'work') {
          // Если отработано меньше 3 часов - не учитываем день вообще
          if (entry.hours_worked && entry.hours_worked < 3) {
            continue
          }

          const weekendNorm = 5
          totalRequiredHours += weekendNorm
          workedDays++

          if (entry.hours_worked) {
            totalWorkedHours += entry.hours_worked

            if (entry.hours_worked < weekendNorm) {
              const missing = weekendNorm - entry.hours_worked
              const formattedDate = `${String(day).padStart(2, '0')}.${String(month).padStart(2, '0')}.${year}`
              issues.push(`${formattedDate} (выходной): недоработка ${formatHours(missing)} (было ${formatHours(entry.hours_worked)}, норма ${weekendNorm}ч)`)
            }
          } else {
            const formattedDate = `${String(day).padStart(2, '0')}.${String(month).padStart(2, '0')}.${year}`
            issues.push(`${formattedDate} (выходной): нет данных о часах`)
          }
        } else if (entry.status === 'remote') {
          const remoteWeekendNorm = 9
          totalRequiredHours += remoteWeekendNorm
          totalWorkedHours += remoteWeekendNorm
          workedDays++
        }
        continue
      }

      // Норма часов для РАБОЧИХ дней: 9ч будни (Пн-Чт), 8ч пятница
      let requiredHours: number
      let dayName: string

      if (dayOfWeek === 5) {
        // Пятница
        requiredHours = 8
        dayName = 'пятница'
      } else {
        // Понедельник-Четверг
        requiredHours = 9
        dayName = 'будний'
      }

      // Если записи нет вообще - пропускаем (не считаем проблемой)
      if (!entry) {
        continue
      }

      // Если статус vacation/dayoff/unpaid/absent - пропускаем (это нормально)
      if (entry.status === 'vacation' || entry.status === 'dayoff' || entry.status === 'unpaid' || entry.status === 'absent') {
        continue
      }

      // Проверяем только work и remote статусы для РАБОЧИХ дней
      if (entry.status === 'work' || entry.status === 'remote') {
        workedDays++

        // Будни: офис = 9ч (пн-чт) или 8ч (пт) норма, удаленка = 5ч норма
        if (entry.status === 'work') {
          totalRequiredHours += requiredHours

          // Для работы в офисе проверяем часы (включая переработку)
          if (entry.hours_worked) {
            totalWorkedHours += entry.hours_worked

            // Если меньше нормы - добавляем в issues (знак ! будет на ячейке)
            if (entry.hours_worked < requiredHours) {
              const missing = requiredHours - entry.hours_worked
              const formattedDate = `${String(day).padStart(2, '0')}.${String(month).padStart(2, '0')}.${year}`
              issues.push(`${formattedDate} (${dayName}): недоработка ${formatHours(missing)} (было ${formatHours(entry.hours_worked)}, норма ${requiredHours}ч)`)
            }
          } else {
            const formattedDate = `${String(day).padStart(2, '0')}.${String(month).padStart(2, '0')}.${year}`
            issues.push(`${formattedDate} (${dayName}): нет данных о часах`)
          }
        } else if (entry.status === 'remote') {
          // Для удалённой работы в будни норма = 5 часов
          const remoteWeekdayNorm = 5
          totalRequiredHours += remoteWeekdayNorm
          totalWorkedHours += remoteWeekdayNorm
        }
      }
    }

    // Итоговая недоработка = норма - отработано (с учетом переработки в других днях)
    const totalMissingHours = Math.max(0, totalRequiredHours - totalWorkedHours)

    return { issues, totalMissingHours, totalWorkedHours, totalRequiredHours, workedDays }
  }

  const getTotalStats = () => {
    let totalMissing = 0
    let employeesWithIssues = 0

    employees.forEach(emp => {
      const { totalMissingHours } = getEmployeeStats(emp.id)
      if (totalMissingHours > 0) {
        employeesWithIssues++
        totalMissing += totalMissingHours
      }
    })

    return { totalMissing, employeesWithIssues }
  }

  const { totalMissing, employeesWithIssues } = getTotalStats()

  return (
    <div className="timesheet-tab">
      <div className="timesheet-header">
        <div className="timesheet-controls">
          <button onClick={prevMonth} className="btn-month-nav">
            <ChevronLeft size={18} />
          </button>
          <h2>{new Date(year, month - 1).toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' })}</h2>
          <button onClick={nextMonth} className="btn-month-nav">
            <ChevronRight size={18} />
          </button>
        </div>
        <div className="timesheet-actions">
          <button onClick={handleClear} className="btn-clear" title="Очистить табель за текущий месяц">
            <Trash2 size={18} />
            <span>Очистить</span>
          </button>
          <label className="btn-import">
            <Upload size={18} />
            <span>Загрузить табель</span>
            <input type="file" accept=".xlsx,.xls" onChange={handleImport} hidden />
          </label>
        </div>
      </div>

      {totalMissing > 0 && (
        <div className="timesheet-summary">
          <div className="summary-stat">
            <span className="summary-label">Сотрудников с проблемами:</span>
            <span className="summary-value">{employeesWithIssues}</span>
          </div>
          <div className="summary-stat">
            <span className="summary-label">Всего недоработано часов:</span>
            <span className="summary-value error">{formatHours(totalMissing)}</span>
          </div>
        </div>
      )}

      <div className="timesheet-table-wrapper">
        <table className="timesheet-table">
          <thead>
            <tr>
              <th className="timesheet-name-col">ФИО</th>
              {Array.from({ length: daysInMonth }, (_, i) => (
                <th key={i + 1} className="timesheet-day-col">{i + 1}</th>
              ))}
              <th className="timesheet-issues-col">Проблемы</th>
            </tr>
          </thead>
          <tbody>
            {uniqueEmployees.map(emp => {
              const entries = timesheet[emp.id] || []
              const stats = getEmployeeStats(emp.id)
              const { issues, totalMissingHours, totalWorkedHours, totalRequiredHours, workedDays } = stats

              return (
                <tr key={emp.id} className={totalMissingHours > 0 ? 'has-issues' : ''}>
                  <td className={`timesheet-name-cell ${emp.full_name === 'Одинцов Артем Андреевич' ? 'timesheet-name-bold' : ''}`}>
                    {emp.full_name}
                  </td>
                    {Array.from({ length: daysInMonth }, (_, i) => {
                      const day = i + 1
                      const date = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`
                      const dayOfWeek = new Date(date).getDay()

                      // Проверяем новогодние праздники (1-11 января 2026)
                      const isHoliday = year === 2026 && month === 1 && day <= 11
                      const isWeekend = isHoliday || dayOfWeek === 0 || dayOfWeek === 6
                      const entry = entries.find(e => e.work_date === date)

                      // Норма часов
                      let requiredHours: number
                      if (isWeekend) {
                        requiredHours = 5
                      } else if (dayOfWeek === 5) {
                        requiredHours = 8
                      } else {
                        requiredHours = 9
                      }
                      // Проверяем недоработку только для work статуса (remote всегда полный день)
                      const hasShortage = entry?.hours_worked &&
                        entry.status === 'work' &&
                        entry.hours_worked < requiredHours

                      let className = entry ? getStatusClass(entry.status) : 'timesheet-cell timesheet-empty'
                      if (isWeekend) className += ' timesheet-weekend'
                      if (hasShortage) className += ' timesheet-shortage'

                      return (
                        <td key={day} className={className}>
                          {entry && (
                            <div className="timesheet-cell-content">
                              <span className="timesheet-status">{getStatusLabel(entry.status)}</span>
                              {entry.hours_worked && <span className="timesheet-hours">{formatHours(entry.hours_worked)}</span>}
                              {entry.is_correction && <span className="timesheet-correction">К</span>}
                            </div>
                          )}
                        </td>
                      )
                    })}
                    <td className="timesheet-issues-cell">
                      {workedDays > 0 ? (
                        <div className="timesheet-issues-wrapper">
                          <div
                            className={`timesheet-issues ${issues.length > 0 ? 'clickable has-problems' : 'no-problems'}`}
                            onClick={() => setSelectedEmployee({ emp, stats })}
                          >
                            <div className="timesheet-stats-summary">
                              {totalMissingHours > 0 ? (
                                <span className="stat-value error">-{formatHours(totalMissingHours)}</span>
                              ) : (
                                <span>✓</span>
                              )}
                            </div>
                          </div>
                          <div className="timesheet-tooltip">
                            <div className="tooltip-stats">
                              <div className="stat-row">
                                <span className="stat-label">Дней:</span>
                                <span className="stat-value">{workedDays}</span>
                              </div>
                              <div className="stat-row">
                                <span className="stat-label">Отработано:</span>
                                <span className="stat-value">{formatHours(totalWorkedHours)}</span>
                              </div>
                              <div className="stat-row">
                                <span className="stat-label">Норма:</span>
                                <span className="stat-value">{formatHours(totalRequiredHours)}</span>
                              </div>
                              {totalMissingHours > 0 && (
                                <div className="stat-row shortage-row">
                                  <span className="stat-label">Недоработка:</span>
                                  <span className="stat-value error">-{formatHours(totalMissingHours)}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="timesheet-ok">—</div>
                      )}
                    </td>
                  </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {showNotFoundModal && (
        <div className="modal-overlay" onClick={() => !importing && setShowNotFoundModal(false)}>
          <div className="modal-content timesheet-notfound-modal" onClick={e => e.stopPropagation()}>
            <h3>Сотрудники не найдены в базе</h3>
            <div className="notfound-content">
              <p className="notfound-description">
                В табеле найдено {notFoundEmployees.length} сотрудников, которых нет в базе данных.
                Выберите кого добавить:
              </p>
              <div className="notfound-select-all">
                <label>
                  <input
                    type="checkbox"
                    checked={selectedToAdd.size === notFoundEmployees.length}
                    onChange={toggleSelectAll}
                    disabled={importing}
                  />
                  <span>Выбрать всех</span>
                </label>
              </div>
              <div className="notfound-list">
                {notFoundEmployees.map((name, i) => (
                  <label key={i} className="notfound-item">
                    <input
                      type="checkbox"
                      checked={selectedToAdd.has(name)}
                      onChange={() => toggleEmployeeSelection(name)}
                      disabled={importing}
                    />
                    <span>{name}</span>
                  </label>
                ))}
              </div>
            </div>
            <div className="modal-actions">
              <button onClick={() => setShowNotFoundModal(false)} disabled={importing}>
                Отмена
              </button>
              <button onClick={handleConfirmNotFound} disabled={importing} className="btn-primary">
                {importing ? 'Добавление...' : `Добавить (${selectedToAdd.size}) и продолжить`}
              </button>
            </div>
          </div>
        </div>
      )}

      {showPreview && (
        <div className="modal-overlay" onClick={() => setShowPreview(false)}>
          <div className="modal-content timesheet-preview-modal" onClick={e => e.stopPropagation()}>
            <h3>Предпросмотр импорта табеля</h3>
            <div className="timesheet-preview">
              <div className="preview-stats">
                <p><strong>Сотрудников:</strong> {importPreview.length}</p>
                <p><strong>Записей:</strong> {importPreview.reduce((sum, row) => sum + row.entries.length, 0)}</p>
              </div>
              <div className="preview-employees">
                <h4>Будут импортированы:</h4>
                <ul>
                  {importPreview.map((row, i) => (
                    <li key={i}>
                      <strong>{row.full_name}</strong> — {row.entries.length} дней
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <div className="modal-actions">
              <button onClick={() => setShowPreview(false)} disabled={importing}>Отмена</button>
              <button onClick={handleConfirmImport} disabled={importing} className="btn-primary">
                {importing ? 'Импорт...' : 'Импортировать'}
              </button>
            </div>
          </div>
        </div>
      )}

      {selectedEmployee && (
        <>
          <div className="sidebar-overlay" onClick={() => setSelectedEmployee(null)} />
          <div className="employee-sidebar open">
            <div className="sidebar-header">
              <h2>{selectedEmployee.emp.full_name}</h2>
              <button className="sidebar-close" onClick={() => setSelectedEmployee(null)}>
                ×
              </button>
            </div>
            <div className="sidebar-body">
              <div className="employee-info">
                <div className="info-row">
                  <span className="info-label">Должность:</span>
                  <span className="info-value">{selectedEmployee.emp.position}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Группа:</span>
                  <span className="info-value">{selectedEmployee.emp.group_name || '—'}</span>
                </div>
              </div>

              <div className="timesheet-sidebar-stats">
                <h3>Статистика за {new Date(year, month - 1).toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' })}</h3>
                <div className="stats-grid">
                  <div className="stat-item">
                    <span className="stat-label">Рабочих дней:</span>
                    <span className="stat-value">{selectedEmployee.stats.workedDays}</span>
                  </div>
                  <div className="stat-item">
                    <span className="stat-label">Отработано:</span>
                    <span className="stat-value">{formatHours(selectedEmployee.stats.totalWorkedHours)}</span>
                  </div>
                  <div className="stat-item">
                    <span className="stat-label">Норма:</span>
                    <span className="stat-value">{formatHours(selectedEmployee.stats.totalRequiredHours)}</span>
                  </div>
                  {selectedEmployee.stats.totalMissingHours > 0 && (
                    <div className="stat-item shortage">
                      <span className="stat-label">Недоработка:</span>
                      <span className="stat-value error">-{formatHours(selectedEmployee.stats.totalMissingHours)}</span>
                    </div>
                  )}
                </div>
              </div>

              {selectedEmployee.stats.issues.length > 0 && (
                <div className="timesheet-sidebar-issues">
                  <h3>Проблемы</h3>
                  <ul>
                    {selectedEmployee.stats.issues.map((issue, i) => (
                      <li key={i}>{issue}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </>
      )}

      {importing && (
        <div className="modal-overlay">
          <div className="loading-spinner">
            <div className="spinner"></div>
            <p>Загрузка табеля...</p>
          </div>
        </div>
      )}
    </div>
  )
}
