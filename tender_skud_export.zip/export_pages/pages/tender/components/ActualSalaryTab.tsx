import { useState, useEffect } from 'react'
import { ChevronLeft, ChevronRight, ChevronDown, ChevronUp } from 'lucide-react'
import { Employee, TimeEntry } from '../types'
import { formatMoney } from '../utils'

interface Props {
  employees: Employee[]
  onLoadTimesheet: (year: number, month: number) => Promise<{ [employeeId: number]: TimeEntry[] }>
}

export default function ActualSalaryTab({ employees, onLoadTimesheet }: Props) {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [timesheet, setTimesheet] = useState<{ [employeeId: number]: TimeEntry[] }>({})
  const [workNormDays, setWorkNormDays] = useState<number>(22)
  const [expandedRows, setExpandedRows] = useState<Set<number>>(new Set())

  const year = currentDate.getFullYear()
  const month = currentDate.getMonth() + 1
  const daysInMonth = new Date(year, month, 0).getDate()

  useEffect(() => {
    loadData()
  }, [currentDate])

  const loadData = async () => {
    const data = await onLoadTimesheet(year, month)
    setTimesheet(data)

    // Вычисляем норму рабочих дней для месяца
    let norm = 0
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month - 1, day)
      const dayOfWeek = date.getDay()
      const isHoliday = year === 2026 && month === 1 && day <= 11
      if (!isHoliday && dayOfWeek !== 0 && dayOfWeek !== 6) {
        norm++
      }
    }
    setWorkNormDays(norm)
  }

  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 2, 1))
  }

  const nextMonth = () => {
    setCurrentDate(new Date(year, month, 1))
  }

  const toggleRow = (employeeId: number) => {
    const newExpanded = new Set(expandedRows)
    if (newExpanded.has(employeeId)) {
      newExpanded.delete(employeeId)
    } else {
      newExpanded.add(employeeId)
    }
    setExpandedRows(newExpanded)
  }

  const getWorkedDays = (employeeId: number) => {
    const entries = timesheet[employeeId] || []
    let workedDays = 0
    let weekendDays = 0

    const today = new Date()
    const todayYear = today.getFullYear()
    const todayMonth = today.getMonth() + 1
    const todayDay = today.getDate()

    let lastDayToCheck = daysInMonth
    if (year === todayYear && month === todayMonth) {
      lastDayToCheck = todayDay
    } else if (year > todayYear || (year === todayYear && month > todayMonth)) {
      return { workedDays: 0, weekendDays: 0 }
    }

    for (let day = 1; day <= lastDayToCheck; day++) {
      const date = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`
      const dayOfWeek = new Date(date).getDay()
      const isHoliday = year === 2026 && month === 1 && day <= 11
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6

      const entry = entries.find(e => e.work_date === date)
      if (!entry) continue

      if (entry.status === 'work' || entry.status === 'remote') {
        if (isHoliday || isWeekend) {
          // Для выходных: remote всегда считается, work только если >= 3 часов
          if (entry.status === 'remote' || (entry.hours_worked && entry.hours_worked >= 3)) {
            weekendDays++
          }
        } else {
          workedDays++
        }
      }
    }

    return { workedDays, weekendDays }
  }

  const getWorkedDaysDetails = (employeeId: number) => {
    const entries = timesheet[employeeId] || []
    const workDates: string[] = []

    const today = new Date()
    const todayYear = today.getFullYear()
    const todayMonth = today.getMonth() + 1
    const todayDay = today.getDate()

    let lastDayToCheck = daysInMonth
    if (year === todayYear && month === todayMonth) {
      lastDayToCheck = todayDay
    } else if (year > todayYear || (year === todayYear && month > todayMonth)) {
      return workDates
    }

    for (let day = 1; day <= lastDayToCheck; day++) {
      const date = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`
      const dayOfWeek = new Date(date).getDay()
      const isHoliday = year === 2026 && month === 1 && day <= 11
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6

      const entry = entries.find(e => e.work_date === date)
      if (!entry) continue

      if (entry.status === 'work' || entry.status === 'remote') {
        // Для выходных: remote всегда считается, work только если >= 3 часов
        if (isHoliday || isWeekend) {
          if (entry.status !== 'remote' && (!entry.hours_worked || entry.hours_worked < 3)) {
            continue
          }
        }

        const formattedDate = `${String(day).padStart(2, '0')}.${String(month).padStart(2, '0')}.${year}`
        const location = entry.status === 'remote' ? 'Удаленно' : 'Офис'
        const dayType = (isHoliday || isWeekend) ? 'Выходной' : ''
        const label = dayType ? `${formattedDate} (${location}, ${dayType})` : `${formattedDate} (${location})`
        workDates.push(label)
      }
    }

    return workDates
  }

  const calculateActualSalary = (employee: Employee) => {
    const { workedDays, weekendDays } = getWorkedDays(employee.id)
    const totalDays = workedDays + weekendDays
    const dailySalary = employee.current_salary / workNormDays
    const actualSalary = dailySalary * totalDays
    return { workedDays, weekendDays, totalDays, dailySalary, actualSalary }
  }

  const allSalaries = employees.map(emp => ({
    employee: emp,
    ...calculateActualSalary(emp)
  })).filter(s => s.totalDays > 0)
    .sort((a, b) => {
      if (a.employee.full_name === 'Одинцов Артем Андреевич') return -1
      if (b.employee.full_name === 'Одинцов Артем Андреевич') return 1
      return 0
    })

  const totalPlannedFOT = allSalaries.reduce((sum, s) => sum + s.employee.current_salary, 0)
  const totalActualFOT = allSalaries.reduce((sum, s) => sum + s.actualSalary, 0)
  const totalDifference = totalPlannedFOT - totalActualFOT

  return (
    <div className="actual-salary-tab">
      <div className="timesheet-header">
        <div className="timesheet-controls">
          <button onClick={prevMonth} className="btn-month-nav">
            <ChevronLeft size={18} />
          </button>
          <h2>{new Date(year, month - 1).toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' })}</h2>
          <button onClick={nextMonth} className="btn-month-nav">
            <ChevronRight size={18} />
          </button>
        </div>
      </div>

      <div className="salary-summary">
        <div className="summary-card">
          <span className="summary-label">Норма рабочих дней:</span>
          <span className="summary-value">{workNormDays}</span>
        </div>
        <div className="summary-card">
          <span className="summary-label">Плановый ФОТ:</span>
          <span className="summary-value">{formatMoney(totalPlannedFOT)}</span>
        </div>
        <div className="summary-card">
          <span className="summary-label">Фактический ФОТ:</span>
          <span className="summary-value">{formatMoney(totalActualFOT)}</span>
        </div>
        <div className="summary-card">
          <span className="summary-label">Экономия:</span>
          <span className={`summary-value ${totalDifference > 0 ? 'positive' : 'negative'}`}>
            {totalDifference > 0 ? '+' : ''}{formatMoney(totalDifference)}
          </span>
        </div>
      </div>

      <div className="salary-table-wrapper">
        <table className="salary-table">
          <thead>
            <tr>
              <th></th>
              <th>ФИО</th>
              <th>Мес. оклад</th>
              <th>Дневная ставка</th>
              <th>Отработано дней</th>
              <th>Оклад (будни)</th>
              <th>Выходные дни</th>
              <th>Фактический оклад</th>
              <th>Разница</th>
            </tr>
          </thead>
          <tbody>
            {allSalaries.map(({ employee, workedDays, weekendDays, totalDays, dailySalary, actualSalary }) => {
              const difference = employee.current_salary - actualSalary
              const isExpanded = expandedRows.has(employee.id)
              const workDetails = getWorkedDaysDetails(employee.id)
              const weekdaySalary = dailySalary * workedDays
              const weekendSalary = dailySalary * weekendDays

              return (
                <>
                  <tr key={employee.id} onClick={() => toggleRow(employee.id)} style={{ cursor: 'pointer' }}>
                    <td style={{ width: '30px', textAlign: 'center' }}>
                      {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                    </td>
                    <td className={`employee-name ${employee.full_name === 'Одинцов Артем Андреевич' ? 'employee-name-bold' : ''}`}>
                      {employee.full_name}
                    </td>
                    <td>{formatMoney(employee.current_salary)}</td>
                    <td>{formatMoney(dailySalary)}</td>
                    <td>
                      {workedDays} + {weekendDays} = {totalDays}
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginLeft: '4px' }}>
                        / {workNormDays}
                      </span>
                    </td>
                    <td>{formatMoney(weekdaySalary)}</td>
                    <td>{formatMoney(weekendSalary)}</td>
                    <td className="actual-salary">{formatMoney(actualSalary)}</td>
                    <td className={difference > 0 ? 'positive' : difference < 0 ? 'negative' : ''}>
                      {difference > 0 ? '+' : ''}{formatMoney(difference)}
                    </td>
                  </tr>
                  {isExpanded && (
                    <tr key={`${employee.id}-details`} className="expanded-row">
                      <td></td>
                      <td colSpan={8}>
                        <div className="salary-details">
                          <div className="detail-section">
                            <h4>Расшифровка расчета:</h4>
                            <div className="calculation-formula">
                              <p><strong>Дневная ставка:</strong> {formatMoney(employee.current_salary)} / {workNormDays} = {formatMoney(dailySalary)}</p>
                              <p><strong>Оклад (будни):</strong> {formatMoney(dailySalary)} × {workedDays} = {formatMoney(weekdaySalary)}</p>
                              <p><strong>Выходные дни:</strong> {formatMoney(dailySalary)} × {weekendDays} = {formatMoney(weekendSalary)}</p>
                              <p><strong>Фактический оклад:</strong> {formatMoney(weekdaySalary)} + {formatMoney(weekendSalary)} = {formatMoney(actualSalary)}</p>
                              <p><strong>Разница:</strong> {formatMoney(employee.current_salary)} - {formatMoney(actualSalary)} = {formatMoney(difference)}</p>
                            </div>
                          </div>
                          <div className="detail-section">
                            <h4>Отработанные дни ({workDetails.length}):</h4>
                            <div className="work-dates">
                              {workDetails.map((date, idx) => (
                                <span key={idx} className="work-date-badge">{date}</span>
                              ))}
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
