import { useState, useEffect } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Employee, TimeEntry } from '../types'

interface Props {
  employees: Employee[]
  onLoadTimesheet: (year: number, month: number) => Promise<{ [employeeId: number]: TimeEntry[] }>
}

export default function TimesheetAnalyticsTab({ employees, onLoadTimesheet }: Props) {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [timesheet, setTimesheet] = useState<{ [employeeId: number]: TimeEntry[] }>({})
  const [workNormDays, setWorkNormDays] = useState<number>(22)
  const [normHours, setNormHours] = useState<number>(0)

  const year = currentDate.getFullYear()
  const month = currentDate.getMonth() + 1
  const daysInMonth = new Date(year, month, 0).getDate()

  useEffect(() => {
    loadData()
  }, [currentDate])

  const loadData = async () => {
    const data = await onLoadTimesheet(year, month)
    setTimesheet(data)

    const today = new Date()
    const todayYear = today.getFullYear()
    const todayMonth = today.getMonth() + 1
    const todayDay = today.getDate()

    // Определяем последний день для расчета нормы
    let lastDayForNorm = daysInMonth
    if (year === todayYear && month === todayMonth) {
      lastDayForNorm = todayDay
    } else if (year > todayYear || (year === todayYear && month > todayMonth)) {
      setWorkNormDays(0)
      setNormHours(0)
      return
    }

    // Вычисляем норму рабочих дней и норму часов до текущего дня
    let norm = 0
    let totalNormHours = 0
    for (let day = 1; day <= lastDayForNorm; day++) {
      const date = new Date(year, month - 1, day)
      const dayOfWeek = date.getDay()
      const isHoliday = year === 2026 && month === 1 && day <= 11
      if (!isHoliday && dayOfWeek !== 0 && dayOfWeek !== 6) {
        norm++
        totalNormHours += dayOfWeek === 5 ? 8 : 9
      }
    }
    setWorkNormDays(norm)
    setNormHours(totalNormHours)
  }

  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 2, 1))
  }

  const nextMonth = () => {
    setCurrentDate(new Date(year, month, 1))
  }

  const getEmployeeStats = (employeeId: number) => {
    const entries = timesheet[employeeId] || []
    let totalWorkedDays = 0
    let totalWorkedHours = 0
    let vacationDays = 0
    let remoteDays = 0
    let absentDays = 0
    let workedWeekendDays = 0
    let totalWeekendDays = 0

    const today = new Date()
    const todayYear = today.getFullYear()
    const todayMonth = today.getMonth() + 1
    const todayDay = today.getDate()

    let lastDayToCheck = daysInMonth
    if (year === todayYear && month === todayMonth) {
      lastDayToCheck = todayDay
    } else if (year > todayYear || (year === todayYear && month > todayMonth)) {
      return { totalWorkedDays, totalWorkedHours, vacationDays, remoteDays, absentDays, workedWeekendDays, totalWeekendDays }
    }

    for (let day = 1; day <= lastDayToCheck; day++) {
      const date = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`
      const dayOfWeek = new Date(date).getDay()
      const entry = entries.find(e => e.work_date === date)

      const isHoliday = year === 2026 && month === 1 && day <= 11
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6

      if (isHoliday || isWeekend) {
        totalWeekendDays++

        if (!entry) continue

        // Считаем отработанные выходные с учетом правила >= 3 часов
        if (entry.status === 'remote' || (entry.status === 'work' && entry.hours_worked && entry.hours_worked >= 3)) {
          workedWeekendDays++
        }

        // Считаем удаленные дни в выходные
        if (entry.status === 'remote') {
          remoteDays++
        }
        continue
      }

      let requiredHours = dayOfWeek === 5 ? 8 : 9

      if (!entry) continue

      if (entry.status === 'vacation') {
        vacationDays++
        continue
      }

      if (entry.status === 'absent') {
        absentDays++
        continue
      }

      if (entry.status === 'dayoff' || entry.status === 'unpaid') continue

      if (entry.status === 'work' || entry.status === 'remote') {
        totalWorkedDays++

        if (entry.status === 'remote') {
          totalWorkedHours += requiredHours
          remoteDays++
        } else if (entry.status === 'work' && entry.hours_worked) {
          totalWorkedHours += entry.hours_worked
        }
      }
    }

    return { totalWorkedDays, totalWorkedHours, vacationDays, remoteDays, absentDays, workedWeekendDays, totalWeekendDays }
  }

  const formatHours = (hours: number) => {
    const h = Math.floor(hours)
    const m = Math.round((hours - h) * 60)
    return `${h}:${String(m).padStart(2, '0')}`
  }

  const allStats = employees.map(emp => ({
    employee: emp,
    ...getEmployeeStats(emp.id)
  })).filter(s => s.totalWorkedDays > 0 || s.vacationDays > 0)
    .sort((a, b) => {
      if (a.employee.full_name === 'Одинцов Артем Андреевич') return -1
      if (b.employee.full_name === 'Одинцов Артем Андреевич') return 1
      return 0
    })

  return (
    <div className="timesheet-analytics-tab">
      <div className="timesheet-header">
        <div className="timesheet-controls">
          <button onClick={prevMonth} className="btn-month-nav">
            <ChevronLeft size={18} />
          </button>
          <h2>{new Date(year, month - 1).toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' })}</h2>
          <button onClick={nextMonth} className="btn-month-nav">
            <ChevronRight size={18} />
          </button>
        </div>
      </div>

      <div className="analytics-table-wrapper">
        <table className="analytics-table">
          <thead>
            <tr>
              <th>ФИО</th>
              <th>Отработано дней</th>
              <th>Отработано часов</th>
              <th>Норма часов</th>
              <th>Выходные дни</th>
              <th>Удаленно</th>
              <th>Отпуск</th>
              <th>Не явка</th>
            </tr>
          </thead>
          <tbody>
            {allStats.map(stat => (
              <tr key={stat.employee.id}>
                <td className={`employee-name ${stat.employee.full_name === 'Одинцов Артем Андреевич' ? 'employee-name-bold' : ''}`}>
                  {stat.employee.full_name}
                </td>
                <td>{stat.totalWorkedDays} / {workNormDays}</td>
                <td>{formatHours(stat.totalWorkedHours)}</td>
                <td>{formatHours(normHours)}</td>
                <td>{stat.workedWeekendDays} / {stat.totalWeekendDays}</td>
                <td>{stat.remoteDays > 0 ? stat.remoteDays : '-'}</td>
                <td>{stat.vacationDays > 0 ? stat.vacationDays : '-'}</td>
                <td className={stat.absentDays > 0 ? 'error' : ''}>
                  {stat.absentDays > 0 ? stat.absentDays : '-'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
